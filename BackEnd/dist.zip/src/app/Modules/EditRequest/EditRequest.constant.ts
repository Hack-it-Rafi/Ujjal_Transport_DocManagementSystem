import { TType } from "./EditRequest.interface";

export const Types : TType[] = [
    'Tax' , 'Fitness' , 'Registration' , 'RoutePermit'
]