export const USER_ROLE = {
  editor: 'editor',
  admin: 'admin',
} as const;

export const userSearchableFields = [
  'email',
  'name',
  'presentAddress',
];
