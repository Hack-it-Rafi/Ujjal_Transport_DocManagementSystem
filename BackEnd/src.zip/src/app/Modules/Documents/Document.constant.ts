import { TType } from "./Document.interface";

export const Types : TType[] = [
    'Tax' , 'Fitness' , 'Registration' , 'RoutePermit', 'Other'
]